NREL CSR model data for Africa.

Data are in a spreadsheet file "csr_africa_data.xls".  Monthly average values for Direct Normal, Global
 Horizontal, Diffuse, and Global on Latitude Tilt are provided.

Data are coded by location using a 6 or 7 digit Cell ID number.

Cell ID maps are provided for 75 regions of Africa.  The key to these regional maps is a map file 
"africa_cellreg.pdf".  The Cell ID maps are called "afr_region_1.pdf, afr_region_2.pdf,...,afr_region_75.pdf".

To access data:

1. Open key map file "africa_cellreg.pdf" using Adobe Reader.
2. Choose the region you are interested in.  Then open the CellID map for that region using Adobe reader.
3. Zoom in on area you are interested in.    Choose cell you want to view.
4. Open csr_africa_data.xls using Excel.
5. Select Chart worksheet (should be default worksheet).
6. From cellnumber map, Use "Select" or "Text Select" tool.  Highlight and copy 6 digit cell number.
7. Paste cell number into cell B1 of Chart.  Alternatively, just type the cell number into this cell.
8. Verify that the Return Cell in column B is the same value you requested.  If not, you have requested a 
   cell that in not in the dataset.
9. Your chart displays the requested data.


For GIS users, we also provide a "shapefile" with the polygon shapes for all the 40 km cells. This file is 
called "csr_afr_poly.shp".  To access the CSR data using a GIS system such as ESRI ArcView or ArcGIS, follow
these directions.

1.  Open csr_africa_data.xls using Excel.
2.  Select a data sheet such as "csr_africa_glo" for global horizontal radiation.
3.  Use "file>save as" , and select the file type "csv" for comma delimited (or .txt or .dbf).  Save the file.
4.  In ArcView or ArcGIS, open csr_afr_poly.shp, and open new file csr_africa_glo.csv as a table.  
5.  "Join" the table to the shapefile, using the field "PSECELLID" from the table and "Psecellid" from the shapefile.
  







